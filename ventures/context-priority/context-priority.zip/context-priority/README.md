# Context Priority

Local, deterministic transcript selection. Keep critical exchanges verbatim instead of letting recent tangents take the whole continuation budget. No model calls, uploads, live compaction or runtime dependencies.

The board references [claude-code #83489](https://github.com/anthropics/claude-code/issues/83489), which requests named model/effort presets. This tool implements the board's **separate context-priority brief**, not that upstream feature.

## Install and use

Download `site/context-priority.zip`, unzip, and run from the extracted directory. Requires Node 20+. No npm install. macOS, Linux and Colima use the same commands:

```sh
node cli.cjs annotate sample.jsonl priorities.json e001=pinned e003=aside
node cli.cjs export sample.jsonl priorities.json 1000 ./out
node --test tests/*.test.cjs
```

`annotate` prints the exchange count; IDs are e001, e002… in source order. Unannotated exchanges default to normal. To change priorities, rerun annotate with the complete desired mapping. Existing sidecars and outputs require a terminal and explicit `OVERWRITE`; noninteractive overwrite is refused. No force flag. The source is never opened for writing. Outputs use private file permissions. Back up sensitive source files yourself.

`out/continuation.md` contains complete exchanges in chronological order inside JSONL code blocks. Pinned JSONL payloads retain their original whitespace and line endings, without paraphrasing. `out/omissions.json` lists every exchange, priority, framed byte cost, selected/omitted status, reason and source SHA-256. Annotations are separate JSON with `version:1`, `sourceSha256`, `priorities`. A changed source invalidates its sidecar.

## Input contract

UTF-8 JSONL, one ordered message per line, no blank lines. Supported records:

- `{ "role":"user", "content":"prompt" }`, assistant records, and `{ "role":"tool", "tool_call_id":"id", "content":"result" }`.
- Assistant `tool_calls` IDs paired with tool `tool_call_id`.
- Message-wrapped `{ "type":"user", "message":{ "role":"user", "content": [...] } }` / assistant records; content blocks may include `tool_use` with `id` and `tool_result` with `tool_use_id`.

An exchange starts at a user prompt and ends with an assistant response before the next user prompt. Result-only user records belong to the ongoing exchange. All tool calls must have matching results in the same exchange. Orphaned results, outstanding calls, a final user prompt, missing final assistant response, mixed result/text user blocks, unsupported roles and metadata records fail closed. This is a strict subset of exported JSONL, **not a universal Claude export importer**. Normalize linear message history first; do not feed a branching raw session log.

## Selection and limits

`site/engine.js` is the exact same module used by CLI and browser. All pinned exchanges are reserved first. A budget below the pinned content plus Markdown framing is rejected. Then normal exchanges are considered oldest-first, then asides oldest-first, skipping whole exchanges that do not fit. Output restores source chronology. The UTF-8 byte budget includes the full Markdown packet, **not the manifest**, and is not a token count. No exchange splitting, summarization or semantic dependency detection. Separate exchanges may reference omitted material: inspect before continuing. Fences grow to safely contain literal backticks.

Export stages both artifacts before publishing. A process or filesystem failure during the two renames can leave one new output and one old output; this is not a transactional two-file replace. Remaining staged artifacts stay in the reported `.context-priority-*` directory for recovery. Output aliases of the source/sidecar, symlink files and hard-linked output files are refused. Concurrent writers to the same output directory are unsupported; use a fresh directory per run. No secrets are redacted: exported content is as sensitive as the source.

## Browser demo / launch

Open `site/index.html` locally. Only the bundled synthetic transcript is demonstrated: no upload control, no network calls from the demo, no external scripts/fonts/trackers. Change priorities or byte budget; download the packet and omission manifest. The free CLI zip remains available without signup. Signup is a plain POST to the existing `/api/signup` service and therefore needs the published route; it does not work from `file://`. Successful `?joined=1#join` displays thanks. Paid tiers are unbuilt founding-price ideas with no checkout.

Generate the download after source changes:

```sh
python3 build.py
```

The build includes only CLI, engine, sample, README and core/CLI tests. Screenshots and test receipts are in `evidence/`. There is no Fly, Boring, model preset or live session integration. Publishing is handled by the existing runner after the issue reply.
