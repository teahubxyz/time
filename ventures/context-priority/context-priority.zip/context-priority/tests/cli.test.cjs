const test=require('node:test');const assert=require('node:assert/strict');const fs=require('node:fs');const os=require('node:os');const path=require('node:path');const {spawnSync}=require('node:child_process');
const cli=path.resolve(__dirname,'../cli.cjs');const sample=fs.readFileSync(path.resolve(__dirname,'../sample.jsonl'));
test('CLI export, hash guard, noninteractive overwrite refusal, source aliases and recovery-safe preflight',()=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'priority-test-'));
 try {
 const source=path.join(dir,'source.jsonl'),side=path.join(dir,'side.json'),out=path.join(dir,'out');fs.writeFileSync(source,sample);
 const run=(...args)=>spawnSync(process.execPath,[cli,...args],{encoding:'utf8'});
 assert.equal(run('annotate',source,side,'e001=pinned','e003=aside').status,0);
 assert.equal(run('export',source,side,'1000',out).status,0);
 const packet=fs.readFileSync(path.join(out,'continuation.md'));const manifest=JSON.parse(fs.readFileSync(path.join(out,'omissions.json')));
 assert.equal(packet.length,manifest.packetBytes);assert.ok(packet.length<=1000);assert.ok(packet.includes(Buffer.from('Never delete customer records.')));
 assert.equal(fs.statSync(path.join(out,'continuation.md')).mode&0o777,0o600);
 assert.match(run('export',source,side,'1000',out).stderr,/terminal/);assert.deepEqual(fs.readFileSync(path.join(out,'continuation.md')),packet);
 assert.match(run('annotate',source,side).stderr,/terminal/);
 assert.match(run('annotate',source,source).stderr,/overwrite an input/);
 const alias=path.join(dir,'alias.json');fs.symlinkSync(source,alias);assert.match(run('annotate',source,alias).stderr,/regular file/);
 const hard=path.join(dir,'hard.json');fs.linkSync(source,hard);assert.match(run('annotate',source,hard).stderr,/regular file/);
 assert.equal(run('export',source,side,'0',path.join(dir,'tiny')).status,1);assert.ok(!fs.existsSync(path.join(dir,'tiny')));
 fs.appendFileSync(source,' ');assert.match(run('export',source,side,'1000',path.join(dir,'changed')).stderr,/Blank line|match/);
 fs.writeFileSync(source,sample);assert.deepEqual(fs.readFileSync(source),sample);
 const trap=path.join(dir,'trap');fs.mkdirSync(trap);fs.symlinkSync(source,path.join(trap,'omissions.json'));
 assert.equal(run('export',source,side,'1000',trap).status,1);assert.ok(!fs.existsSync(path.join(trap,'continuation.md')));assert.deepEqual(fs.readFileSync(source),sample);
 }finally{fs.rmSync(dir,{recursive:true,force:true});}
});
