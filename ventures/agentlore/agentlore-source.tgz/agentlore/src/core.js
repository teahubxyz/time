export function parseRepos(input) {
 const urls=input.trim().split(/\s+/).filter(Boolean);
 if(!urls.length||urls.length>3) throw Error('Enter one to three public GitHub repository URLs.');
 return [...new Set(urls.map(s=>{const u=new URL(s);const m=u.pathname.match(/^\/([\w.-]+)\/([\w.-]+)\/?$/);if(u.protocol!=='https:'||u.hostname!=='github.com'||u.username||u.password||u.search||u.hash||!m)throw Error('Use https://github.com/owner/repository URLs without branches or query strings.');return m[1]+'/'+m[2].replace(/\.git$/,'');}))];
}
export function eligible(path) {return /(^|\/)(AGENTS|CLAUDE|CONTRIBUTING|copilot-instructions|instructions|rules)\.md$/i.test(path)||/(^|\/)\.cursor\/rules\/[^/]+\.mdc$/i.test(path);}
export function extract(text,repo,path,sha) {
 let fenced=false;const rows=[];
 text.split(/\r?\n/).forEach((line,i)=>{if(/^\s*(```|~~~)/.test(line)){fenced=!fenced;return;}if(fenced)return;
 const plain=line.replace(/^\s*(?:[-*+]\s+|\d+[.)]\s+)/,'').trim();
 if(plain.length<15||plain.length>800||/^\s*[#>|]/.test(line)||!(/\b(must|should|always|never|avoid|prefer|ensure|do not|don't|required)\b/i.test(plain)||/^(use|run|keep|write|test|check|add|follow|make|include|read|verify)\b/i.test(plain)))return;
 const project=path.includes('/')||/`|\b(npm|pnpm|yarn|cargo|pytest|docker|this repo|this project|directory|package|component)\b|\.[a-z]{1,4}\b|https?:\/\//i.test(plain);
 rows.push({text:line.trim(),repo,path,sha,line:i+1,kind:project?'project':'reusable',url:`https://github.com/${repo}/blob/${sha}/${path.split('/').map(encodeURIComponent).join('/')}#L${i+1}`,flags:[]});});return rows;
}
export function annotate(rows) {
 const groups=new Map();for(const r of rows){const key=r.text.toLowerCase().replace(/[^a-z0-9 ]/g,'').replace(/\s+/g,' ').trim();if(groups.has(key)){r.flags.push('Duplicate');for(const other of groups.get(key))if(!other.flags.includes('Duplicate'))other.flags.push('Duplicate');groups.get(key).push(r);}else groups.set(key,[r]);}
 for(let i=0;i<rows.length;i++)for(let j=i+1;j<rows.length;j++) {const a=rows[i],b=rows[j];const neg=s=>/\b(never|not|avoid|don't)\b/i.test(s);const words=s=>new Set(s.toLowerCase().match(/[a-z]{4,}/g)?.filter(w=>!['never','always','should','must','avoid','prefer'].includes(w))||[]);const wa=words(a.text),wb=words(b.text);const common=[...wa].filter(w=>wb.has(w)).length;if(neg(a.text)!==neg(b.text)&&common>=2&&common/Math.max(wa.size,wb.size)>.5){for(const r of [a,b])if(!r.flags.includes('Possible conflict'))r.flags.push('Possible conflict');}}
 return rows;
}
export function exportMarkdown(rows) {return '# AGENTS.md\n\n<!-- Human-reviewed exact excerpts. Recheck source license, context and scope before adopting. -->\n\n'+rows.map(r=>`<!-- Source: ${r.url}; original scope: ${r.path.includes('/')?r.path.slice(0,r.path.lastIndexOf('/')):'repository root'} -->\n${/^[-*+]\s/.test(r.text)?r.text:'- '+r.text}\n`).join('\n');}

