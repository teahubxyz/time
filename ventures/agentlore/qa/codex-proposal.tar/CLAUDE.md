<!-- AgentLore proposed reference; verify your agent supports this syntax. -->
@AGENTS.md
