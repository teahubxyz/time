# Instructions for codex-rs/exec-server/src/sandbox_integrity/

<!-- AgentLore draft for openai/codex @ 0c329ad2c9d5a2592128a1d536c66e16f9397e46. Generated structure is a recommendation, not an extracted convention. Review licenses, scope and contradictions before applying. -->

Scope: files below codex-rs/exec-server/src/sandbox_integrity/. Read root AGENTS.md first; review any conflicting root and local rules explicitly.

<!-- Exact excerpt: https://github.com/openai/codex/blob/0c329ad2c9d5a2592128a1d536c66e16f9397e46/codex-rs/exec-server/src/sandbox_integrity/AGENTS.md#L3; original scope: codex-rs/exec-server/src/sandbox_integrity/AGENTS.md -->
These checks currently emit telemetry only. Findings and preparation errors must

<!-- Exact excerpt: https://github.com/openai/codex/blob/0c329ad2c9d5a2592128a1d536c66e16f9397e46/codex-rs/exec-server/src/sandbox_integrity/AGENTS.md#L19; original scope: codex-rs/exec-server/src/sandbox_integrity/AGENTS.md -->
results. Never emit paths, environment values, or error text.
