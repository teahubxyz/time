# Project instructions

<!-- AgentLore draft for openai/codex @ 0c329ad2c9d5a2592128a1d536c66e16f9397e46. Generated structure is a recommendation, not an extracted convention. Review licenses, scope and contradictions before applying. -->

## Reviewed root conventions

<!-- No root conventions selected. Add only after reviewing project evidence. -->

## Scoped instructions

- [docs/AGENTS.md](docs/AGENTS.md) — applies inside docs/ only.
- [codex-rs/exec-server/src/sandbox_integrity/AGENTS.md](codex-rs/exec-server/src/sandbox_integrity/AGENTS.md) — applies inside codex-rs/exec-server/src/sandbox_integrity/ only.

## Source-of-truth documentation

- [README.md](https://github.com/openai/codex/blob/0c329ad2c9d5a2592128a1d536c66e16f9397e46/README.md) — read; retain as source of truth
- [codex-rs/README.md](https://github.com/openai/codex/blob/0c329ad2c9d5a2592128a1d536c66e16f9397e46/codex-rs/README.md) — read; retain as source of truth
- [docs/agents_md.md](https://github.com/openai/codex/blob/0c329ad2c9d5a2592128a1d536c66e16f9397e46/docs/agents_md.md) — read; retain as source of truth
- [docs/authentication.md](https://github.com/openai/codex/blob/0c329ad2c9d5a2592128a1d536c66e16f9397e46/docs/authentication.md) — read; retain as source of truth
- [docs/CLA.md](https://github.com/openai/codex/blob/0c329ad2c9d5a2592128a1d536c66e16f9397e46/docs/CLA.md) — read; retain as source of truth
- [docs/config.md](https://github.com/openai/codex/blob/0c329ad2c9d5a2592128a1d536c66e16f9397e46/docs/config.md) — read; retain as source of truth
- [docs/example-config.md](https://github.com/openai/codex/blob/0c329ad2c9d5a2592128a1d536c66e16f9397e46/docs/example-config.md) — inventoried only; review before adoption
- [docs/exec.md](https://github.com/openai/codex/blob/0c329ad2c9d5a2592128a1d536c66e16f9397e46/docs/exec.md) — inventoried only; review before adoption

## Task skills

- [codex-rs/skills/src/assets/samples/imagegen/SKILL.md](codex-rs/skills/src/assets/samples/imagegen/SKILL.md) — existing skill retained; review its trigger.
