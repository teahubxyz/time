# Instructions for docs/

<!-- AgentLore draft for openai/codex @ 0c329ad2c9d5a2592128a1d536c66e16f9397e46. Generated structure is a recommendation, not an extracted convention. Review licenses, scope and contradictions before applying. -->

Scope: files below docs/. Read root AGENTS.md first; review any conflicting root and local rules explicitly.

<!-- Exact excerpt: https://github.com/openai/codex/blob/0c329ad2c9d5a2592128a1d536c66e16f9397e46/docs/contributing.md#L5; original scope: docs/contributing.md -->
**We do not accept external code contributions or pull requests.**
